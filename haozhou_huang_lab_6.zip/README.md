# FiniteStateMachine-DCN2024

Name of Class containing the main() method: Main